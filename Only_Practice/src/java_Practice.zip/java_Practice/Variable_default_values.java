package java_Practice;


public class Variable_default_values {
	
	int a;// default value is zero if it is class variable
	

	
	public static void mm()
	{
		//we can have try block without catch 
		// we can have try with finally without catch block
		
		try {
			System.out.println("");
		} finally {
			// TODO: handle finally clause
		}
		
	}

}
