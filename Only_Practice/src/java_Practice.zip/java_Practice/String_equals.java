package java_Practice;

public class String_equals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String s="mahesh";
		String p="mahesh";
        
		String x=new String("mahesh");
		String y=new String("mahesh");
		
		
		System.out.println(s==p);
		System.out.println(s.equals(p));
		
		
		System.out.println(x==y);
		System.out.println(x.equals(y));
	}

}
