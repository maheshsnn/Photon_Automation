package java_Practice;

public class Matrix_Transpose {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] x={{1,3,4},{2,4,3},{3,4,5}};
		
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x.length;j++)
			{
				System.out.print(x[j][i]); 
				
			}
			System.out.println();
		}

	}

}
